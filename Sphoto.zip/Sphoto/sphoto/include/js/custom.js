jQuery(document).ready(function($){


  //$('.loader-wrapper').fadeOut();
$('.loader').delay(2000).fadeOut('slow');





   var owlHero = $('.hero-slider');
  if (owlHero.length) {
    owlHero.on('initialized.owl.carousel', function(event) {
      owlHero.find('.owl-item.active').find('.animated').each(function() {
        $(this).addClass($(this).data('animate'));
      });
    });
    owlHero.owlCarousel({
      items: 1,
      loop: true,
      dots:false,
      nav: true,
      navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
      autoplay:true,
      // autoplayHoverPause:true,
      autoplayTimeout: 4000
    });
    owlHero.on('changed.owl.carousel', function(event) {
      var owlItem = owlHero.find('.owl-item');
      owlItem.find('.animated').each(function() {
        $(this).removeClass($(this).data('animate'));
      });
      owlItem.eq(event.item.index).find('.animated').each(function() {
        $(this).addClass($(this).data('animate'));
      });
    });
  }

/*==========================*/  
/* Scroll on animate */  
/*==========================*/
function onScrollInit( items, trigger ) {
  items.each( function() {
    var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
      
        osElement.css({
          '-webkit-animation-delay':  osAnimationDelay,
          '-moz-animation-delay':     osAnimationDelay,
          'animation-delay':          osAnimationDelay
        });

        var osTrigger = ( trigger ) ? trigger : osElement;
        
        osTrigger.waypoint(function() {
          osElement.addClass('animated').addClass(osAnimationClass);
          },{
              triggerOnce: true,
              offset: '90%'
        });
  });
}

onScrollInit( $('.os-animation') );
onScrollInit( $('.staggered-animation'), $('.staggered-animation-container') );
   




   /*==========================*/  
/* Scroll on animate */  
/*==========================*/
function onScrollInit( items, trigger ) {
  items.each( function() {
    var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
      
        osElement.css({
          '-webkit-animation-delay':  osAnimationDelay,
          '-moz-animation-delay':     osAnimationDelay,
          'animation-delay':          osAnimationDelay
        });

        var osTrigger = ( trigger ) ? trigger : osElement;
        
        osTrigger.waypoint(function() {
          osElement.addClass('animated').addClass(osAnimationClass);
          },{
              triggerOnce: true,
              offset: '90%'
        });
  });
}

onScrollInit( $('.os-animation') );
onScrollInit( $('.staggered-animation'), $('.staggered-animation-container') );




$(function() {
    $('.navbar-nav a.nav-link,.footer-nav a.nav-link').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top 
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });
});

   $(".navbar-nav li a").click(function (event) {
    var toggle = $(".navbar-toggler").is(":visible");
    if (toggle) {
      $(".navbar-collapse").collapse('hide');
    }
  });





$("#feedback-outer").owlCarousel({
    autoPlay : 3000,
    items: 1,
    stopOnHover : true,
    navigation:true,
    paginationSpeed : 1000,
    goToFirstSpeed : 2000,
    singleItem : true,
    autoHeight : true,
    center:true,
 
 });










	
/*==========================*/  
/* Masonry */ 
/*==========================*/
$(function () {
  var self = $("#masonry");

  
  // init Masonry
  var $grid = $('.grid').masonry({
    itemSelector: '.grid-item',
    percentPosition: true,
    columnWidth: '.grid-sizer',
  gutter: '.gutter-sizer',
  });
  // layout Isotope after each image loads
  $grid.imagesLoaded().progress( function() {
    $grid.masonry();
  });  

  $("ul.work-category li a").click(function(e) {
    e.preventDefault();
    $('ul.work-category li a').removeClass('active');
    $(this).addClass('active');
    var filter = $(this).attr("data-filter");

    self.masonryFilter({
      filter: function () {
        if (!filter) return true;
        return $(this).attr("data-filter") == filter;
      }
    });
  });
});

$('.my-work').each(function() { // the containers for all your galleries
    $(this).magnificPopup({
        delegate: 'a', // the selector for gallery item
        type: 'image',
        gallery: {
          enabled:true
        },
          mainClass: 'mfp-with-zoom', // this class is for CSS animation below

  zoom: {
    enabled: true, // By default it's false, so don't forget to enable it

    duration: 300, // duration of the effect, in milliseconds
    easing: 'ease-in-out', // CSS transition easing function

    // The "opener" function should return the element from which popup will be zoomed in
    // and to which popup will be scaled down
    // By defailt it looks for an image tag:
    opener: function(openerElement) {
      // openerElement is the element on which popup was initialized, in this case its <a> tag
      // you don't need to add "opener" option if this code matches your needs, it's defailt one.
      return openerElement.is('img') ? openerElement : openerElement.find('img');
    }
  }

    });
});




var scroll = $(window).scrollTop();

    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
  
}); 

  

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }


    
});
 
